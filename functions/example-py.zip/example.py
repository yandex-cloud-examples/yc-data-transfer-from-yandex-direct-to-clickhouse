# -*- coding: utf-8 -*-
# последняя версия доступна здесь https://yandex.ru/dev/direct/doc/examples-v5/python3-requests-campaigns.html
import sys
import os
import json

import requests
import awswrangler as wr
import pandas as pd

def foo(event, context):
    if sys.version_info < (3,):
        def u(x):
            try:
                return x.encode("utf8")
            except UnicodeDecodeError:
                return x
    else:
        def u(x):
            if type(x) == type(b''):
                return x.decode('utf8')
            else:
                return x

    # --- Входные данные ---

    #  Адрес сервиса Campaigns для отправки JSON-запросов (регистрозависимый)
    # CampaignsURL = 'https://api.direct.yandex.com/json/v5/campaigns'
    
    # если используете песочницу
    CampaignsURL = 'https://api-sandbox.direct.yandex.com/json/v5/campaigns'

    # OAuth-токен пользователя, от имени которого будут выполняться запросы
    TOKEN = BUCKET = os.environ['TOKEN']
    BUCKET = os.environ['BUCKET']

    # Логин клиента рекламного агентства
    # Обязательный параметр, если запросы выполняются от имени рекламного агентства
    # clientLogin = 'ЛОГИН_КЛИЕНТА'

    # --- Подготовка, выполнение и обработка запроса ---
    #  Создание HTTP-заголовков запроса
    headers = {"Authorization": "Bearer " + TOKEN,  # OAuth-токен. Использование слова Bearer обязательно
            # "Client-Login": clientLogin,  # Логин клиента рекламного агентства
            "Accept-Language": "ru",  # Язык ответных сообщений
            }

    # Создание тела запроса
    body = {"method": "get",  # Используемый метод.
            "params": {"SelectionCriteria": {},  # Критерий отбора кампаний. Для получения всех кампаний должен быть пустым
                    "FieldNames": ["Id", "Name"]  # Имена параметров, которые требуется получить.
                    }}
    
    # Кодирование тела запроса в JSON
    jsonBody = json.dumps(body, ensure_ascii=False).encode('utf8')

    # Выполнение запроса
    try:
        result = requests.post(CampaignsURL, jsonBody, headers=headers)

        # Отладочная информация
        # print("Заголовки запроса: {}".format(result.request.headers))
        # print("Запрос: {}".format(u(result.request.body)))
        # print("Заголовки ответа: {}".format(result.headers))
        # print("Ответ: {}".format(u(result.text)))
        # print("\n")

        # Обработка запроса
        if result.status_code != 200 or result.json().get("error", False):
            print("Произошла ошибка при обращении к серверу API Директа.")
            print("Код ошибки: {}".format(result.json()["error"]["error_code"]))
            print("Описание ошибки: {}".format(u(result.json()["error"]["error_detail"])))
            print("RequestId: {}".format(result.headers.get("RequestId", False)))
        else:
            print("RequestId: {}".format(result.headers.get("RequestId", False)))
            print("Информация о баллах: {}".format(result.headers.get("Units", False)))

            json_result = result.json()
            # или пример для оффлайна
            # json_result = json.loads("{'result': {'Campaigns': [{'Id': 462266, 'Name': 'Test API Sandbox campaign 1'}, {'Id': 462267, 'Name': 'Test API Sandbox campaign 2'}, {'Id': 462268, 'Name': 'Test API Sandbox campaign 3'}]}}")

            df_result = pd.DataFrame(json_result['result']['Campaigns'])
            wr.config.s3_endpoint_url = 'https://storage.yandexcloud.net'

            wr.s3.to_parquet(
                df=df_result,
                path=f's3://{BUCKET}/',
                dataset=True)

    # Обработка ошибки, если не удалось соединиться с сервером API Директа
    except requests.exceptions.ConnectionError:
        # В данном случае мы рекомендуем повторить запрос позднее
        print("Произошла ошибка соединения с сервером API.")

    # Если возникла какая-либо другая ошибка
    except Exception as exc:
        # В данном случае мы рекомендуем проанализировать действия приложения
        print(str(exc))
        print("Произошла непредвиденная ошибка.")